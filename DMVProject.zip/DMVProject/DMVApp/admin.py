from django.contrib import admin
from .models import testModel


# Register your models here.
admin.site.register(testModel)