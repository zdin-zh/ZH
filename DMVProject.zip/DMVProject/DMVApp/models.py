from django.db import models


# Create your models here.
class testModel(models.Model):
    name = models.CharField(max_length=100)
    imageFile = models.ImageField(upload_to='DMVApp/')
    updated = models.DateTimeField(auto_now=True, auto_now_add=False)
    

    def __unicode__(self):
        return self.name

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse("index", kwargs={"id": self.id})

    class Meta:
        ordering = ["-updated"]      
