from django.apps import AppConfig


class DmvappConfig(AppConfig):
    name = 'DMVApp'
