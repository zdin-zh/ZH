import urllib.request
urllib.request.urlretrieve ("http://feeds.reuters.com/Reuters/worldNews", "worldNews.xml")
