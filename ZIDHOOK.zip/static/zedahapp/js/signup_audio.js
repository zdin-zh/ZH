function StopAllAudio(){
  $('#username_audio').get(0).pause();
  $('#username_audio').get(0).currentTime = 0;
  $('#password_audio').get(0).pause();
  $('#password_audio').get(0).currentTime = 0;
  $('#important_notice_audio').get(0).pause();
  $('#important_notice_audio').get(0).currentTime = 0;
  $('#narrator_audio').get(0).pause();
  $('#narrator_audio').get(0).currentTime = 0;
  $('#01').get(0).pause();
  $('#01').get(0).currentTime = 0;
  $('#02').get(0).pause();
  $('#02').get(0).currentTime = 0;
  $('#03').get(0).pause();
  $('#03').get(0).currentTime = 0;
  $('#04').get(0).pause();
  $('#04').get(0).currentTime = 0;
  $('#05').get(0).pause();
  $('#05').get(0).currentTime = 0;
  $('#06').get(0).pause();
  $('#06').get(0).currentTime = 0;
  $('#07').get(0).pause();
  $('#07').get(0).currentTime = 0;
  $('#08').get(0).pause();
  $('#08').get(0).currentTime = 0;
  $('#09').get(0).pause();
  $('#09').get(0).currentTime = 0;
  $('#10').get(0).pause();
  $('#10').get(0).currentTime = 0;
  $('#11').get(0).pause();
  $('#11').get(0).currentTime = 0;
  $('#12').get(0).pause();
  $('#12').get(0).currentTime = 0;
  $('#13').get(0).pause();
  $('#13').get(0).currentTime = 0;
  $('#14').get(0).pause();
  $('#14').get(0).currentTime = 0;
  $('#15').get(0).pause();
  $('#15').get(0).currentTime = 0;
  $('#16').get(0).pause();
  $('#16').get(0).currentTime = 0;
  $('#17').get(0).pause();
  $('#17').get(0).currentTime = 0;
  $('#18').get(0).pause();
  $('#18').get(0).currentTime = 0;
  $('#19').get(0).pause();
  $('#19').get(0).currentTime = 0;
  $('#20').get(0).pause();
  $('#20').get(0).currentTime = 0;
  
  $('#signup_audio').get(0).pause();
  $('#signup_audio').get(0).currentTime = 0;
};

// Audio for the blind
// Sign-up
function SignupAudio(){
  $('#username-signup').focusin(function(){
    StopAllAudio();
    $('#username_audio').get(0).play();
  });
  $('#password-signup').focusin(function(){
    StopAllAudio();
    $('#password_audio').get(0).play();
  });
  $('#notice').focusin(function(){
    StopAllAudio();
    $('#important_notice_audio').get(0).play();
  });
  $('#narrator').focusin(function(){
    StopAllAudio();
    $('#important_narrator_audio').get(0).play();
  });

  
  $('#signup-button').focusin(function(){
    StopAllAudio();
    $('#signup_now_audio').get(0).play();
  });
};
